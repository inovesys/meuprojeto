# InoveSys ERP - Electron Desktop Final Build

## Estrutura Finalizada

### Builds Gerados
- **InoveSys-ERP-1.0.0-portable.zip** (140MB) - Distribuível sem instalação
  - Contém: InoveSys ERP.exe + todas as dependências Electron
  - SHA512: `e6fe4f42b6e68d4b0a50949b83f30c4bec3c60ad9f1bbaae367481e1398e686aa23f708d95b23f30e02d1c760d4667c4ddc331f6cfb1d2f5699dac491353142f`
  - Compatível com Windows x64
- **latest.yml** - Metadata para auto-update (electron-updater)

### Configuração Validada

#### 1. Main Process (`electron/main.ts`)
- ✅ Hybrid loading: Remote (https://inovesys-erp.netlify.app) + Local fallback
- ✅ Splash screen customizado (1.8s timeout)
- ✅ Security: Context isolation, nodeIntegration disabled
- ✅ Auto-updater: Checks every 2 hours, manual download
- ✅ Tray integration: Minimize to tray (não sair completamente)
- ✅ Menu customizado: Arquivo, Editar, Visualizar, Ajuda
- ✅ IPC handlers:
  - window controls (minimize, maximize, close)
  - notifications
  - printing
  - external URLs
  - cache management
  - **NEW**: offline storage info, IDB clear, session persistence

#### 2. Preload (`electron/preload.ts`)
- ✅ Safe IPC API expose: window.electronAPI
- ✅ Auto-update listeners (available, progress, downloaded, error)
- ✅ **NEW**: offline debugging (storage info, clear IDB)
- ✅ **NEW**: session persistence placeholders

#### 3. Electron Builder (`electron-builder.json`)
- ✅ Portable target (não requer installer/wine)
- ✅ Proper versioning in artifacts
- ✅ Generic publish provider (compatível com qualquer host)
- ✅ File associations (.erp)
- ✅ Artifact naming: `${productName}-${version}-${arch}.${ext}`

### Integração Offline-First

#### IndexedDB em Electron
- ✅ Totalmente isolado por sessão (cada usuário tem próprio IndexedDB)
- ✅ Armazena até 50MB por database (ilimitado com quota API)
- ✅ Persistente entre restarts (localStorage automático)
- ✅ Sincronização via sync_queue (prioridade de tabelas)

#### Cash Register Offline
- ✅ Salva em IndexedDB ao abrir caixa
- ✅ Sincroniza com prioridade 0 (antes de vendas)
- ✅ UI recarrega ao reconectar (não mostra "fechado" false)
- ✅ Validação: não permite venda sem caixa aberto

#### Sales Offline
- ✅ Salva venda + sale_items + cash_register_movements offline
- ✅ Sync respeta dependências (caixa → venda → itens)
- ✅ Movimentos de caixa atualizam corretamente

#### Login Persistence
- ✅ localStorage mantido entre restarts automaticamente
- ✅ Session autenticação persiste
- ✅ Usuário mantém login ao reiniciar desktop

### Auto-Update Infrastructure

#### Fluxo
1. App inicia, verifica updates (3s após mostrar janela)
2. Se disponível, notifica usuário (não baixa automaticamente)
3. Usuário clica "Baixar" → download + barra de progresso
4. Após download: notifica para reiniciar
5. Próximo restart instala automaticamente

#### Configuração
- URL: `https://inovesys-erp.netlify.app/releases`
- Arquivos necessários em releases/:
  - `latest.yml` - metadata versioning
  - `InoveSys-ERP-1.0.0-portable.zip` - executável

### Debugging & Maintenance

#### Storage Info (Dev Mode)
```typescript
// window.electronAPI.offlineGetStorageInfo()
// Returns: { usage, quota, percent }
```

#### Clear IDB (Emergência)
```typescript
// window.electronAPI.offlineClearIDB()
// Limpa todos os IndexedDBs
```

#### Reload App
```typescript
// window.electronAPI.reload()
```

### Deploy Checklist

- [ ] Copiar `release/InoveSys-ERP-1.0.0-portable.zip` para releases/ do servidor
- [ ] Copiar `release/latest.yml` para releases/ do servidor
- [ ] Testar auto-update em staging
- [ ] Versão 1.0.1 deve estar em electron-builder.json + package.json para próxima build
- [ ] Rodar novo build: `npm run electron:build:win`
- [ ] Gerar novo SHA512 do ZIP
- [ ] Atualizar latest.yml com novo hash/versão

### Próximos Passos (Futuro)

1. **Code Signing**: Adicionar certificado Windows para remover avisos SmartScreen
2. **NSIS Installer**: Configurar wine em CI/CD ou usar GitHub Actions para build
3. **Mac/Linux**: Adicionar targets macOS (dmg) e Linux (AppImage, deb)
4. **Delta Updates**: Implementar apenas-diff downloads (reduza BW de ~140MB para ~20MB)
5. **Encrypted Storage**: Implementar encrypted persistent storage para auth tokens

## Testes Validados

✅ Build Electron sem erros
✅ Preload API exposição segura
✅ Auto-updater listeners registrados
✅ IndexedDB persistence testado
✅ Offline-first integração completa
✅ Cash register offline/online
✅ Sales sync com dependências
✅ Hybrid loading (remote + fallback)
✅ Tray integration
✅ Menu customizado PT-BR

## Versão

- **App**: 1.0.0
- **Electron**: 42.0.0
- **Build Date**: 2026-05-11
- **Target**: Windows x64 (portable)
